from flask import Blueprint

inside_bp = Blueprint("inside_bp", __name__, template_folder="templates")